public class Main
{
	public static void main(String[] args) {
	    int [][] array = {{10,20,30},{40,50,60},{0,0,0}};
	    int rowNum = 0;
	    for (int i = 0 ; i < array.length; i++){
	        for (int j = 0; j < array.length ; j++){
	            if (array[i][j] != 0){
	                break;
	            }else if (j == array.length - 1 && array[i][j] == 0){
	                rowNum = i;
	                break;
	            }
	        }
	    }
	    System.out.println("First all zero row is: " + (rowNum + 1));
	}
}

