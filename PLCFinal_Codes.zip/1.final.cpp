#include <string.h>

#include <iostream>
using namespace std;
int main()
{ int s=1;
char j;
do
{cout<<"enter digit or .";
cin>>j;
cout<<"In state"<<s<<endl;
}while(is_digit(j));
cout<<". entered going to state 2"<<endl;
s=2;
do
{cout<<"enter digit or .";
cin>>j;
cout<<s<endl;
}while(is_digit(j));
return 0;
}


