#include <stdio.h>

int main()
{
    int i,j;
    j = -3;
for (i = 0; i < 3; i++)
{
    int temp = j +2;
    if (temp == 2) goto label_1;
    if (temp == 0) goto label_2;
    if (temp != 3) goto label_3;
    if (j <= 0) goto label_4;
}
    label_1: j--;
    label_2: j += 2;
    label_3: j = 0;
    label_4: j = 3 - 1;
}

