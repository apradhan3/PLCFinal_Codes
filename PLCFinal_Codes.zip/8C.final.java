public class Main
{
	public static void main(String[] args) {
	    int i,j;
	    j = -3;
for (i = 0; i < 3; i++)
{
    int temp = j + 2;
    if (temp == 2) j--;
    else if (temp == 0) j += 2;
    else if (temp != 3) j = 0;
    if (j <= 0) j = 3 - i;
}
	}
}

